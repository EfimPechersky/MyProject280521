package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class LevelActivity extends AppCompatActivity {
    ImageView lifesView;
    Button back;
    ImageButton startbutton,tile1,tile2,tile3,tile4,tile5,tile6;
    int[]tiles={1,2,3,4,5,6,1,2,3,4,5,6};
    long[]delays={3000,1000,4000,3000,2000,1200,3456,6000,2000,2500,1000,1000};
    long alltime=0;
    Level level=new Level(tiles,delays,R.raw.jojo);
    SoundPool mSoundPool1,mSoundPool2,mSoundPool3,mSoundPool4,mSoundPool5,mSoundPool6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);
        for (int i = 0; i <delays.length-1 ; i++) {
            alltime+=delays[i];
        }
        final MyDownCounter myDownCounter=new MyDownCounter(alltime,100,tiles,delays);
        mSoundPool1=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        mSoundPool2=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        mSoundPool3=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        mSoundPool4=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        mSoundPool5=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        mSoundPool6=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        tile1=findViewById(R.id.tile1);
        tile2=findViewById(R.id.tile2);
        tile3=findViewById(R.id.tile3);
        tile4=findViewById(R.id.tile4);
        tile5=findViewById(R.id.tile5);
        tile6=findViewById(R.id.tile6);
        lifesView=findViewById(R.id.lifes);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        startbutton=findViewById(R.id.test);
        back=findViewById(R.id.back);
        tile1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool1.load(LevelActivity.this,R.raw.bassgitarafankzvonkaya,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool1.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool2.load(LevelActivity.this,R.raw.gitarabassodinochnyiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool2.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool3.load(LevelActivity.this,R.raw.gitaraodinochnyiychetkiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool3.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool4.load(LevelActivity.this,R.raw.gitaraodinochnyiyzvonkiysredniy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool4.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool5.load(LevelActivity.this,R.raw.malyiybarabanodinochnyiyrimchetkiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool5.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        tile6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool6.load(LevelActivity.this,R.raw.malyiybarabanodinochnyiyvprostranstveklassicheskiy,1);
                AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                float leftVolume = curVolume / maxVolume;
                float rightVolume = curVolume / maxVolume;
                int priority = 1;
                int no_loop = 0;
                float normal_playback_rate = 1f;
                mSoundPool6.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
            }
        });
        Bundle bundle=new Bundle();
        bundle=getIntent().getExtras();
        Long levelID=bundle.getLong("levelID");
        final Intent intent=new Intent(LevelActivity.this,MainActivity.class);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDownCounter.start();
            }
        });
    }
    class MyDownCounter extends CountDownTimer{
        SoundPool soundPool=new SoundPool(6, AudioManager.STREAM_MUSIC,100);
        boolean onButton=false;
        Button button;
        int [] leveltiles;
        long [] leveldelays;
        long timerTime;
        int counter=0;
        int counterdelays=0;
        boolean loseGame=false;
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        float leftVolume = curVolume / maxVolume;
        float rightVolume = curVolume / maxVolume;
        int priority = 1;
        int no_loop = 0;
        float normal_playback_rate = 1f;
        int lifes=3;
        public MyDownCounter(long millisInFuture, long countDownInterval, int []leveltiles,long []leveldelays) {
            super(millisInFuture, countDownInterval);
            this.leveltiles=leveltiles;
            this.leveldelays=leveldelays;
            timerTime=countDownInterval;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            switch (lifes){
                case(0):lifesView.setImageResource(R.drawable.life0);loseGame=true;break;
                case(1):lifesView.setImageResource(R.drawable.life1);break;
                case(2):lifesView.setImageResource(R.drawable.lifes2);break;
                case(3):lifesView.setImageResource(R.drawable.lifes3);break;
            }
            if (loseGame){
                onFinish();
            }
            counter+=1;
            soundPool.load(LevelActivity.this,R.raw.error,0);
            switch(leveltiles[counterdelays]){
                case(1):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=true;
                        mSoundPool1.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });;break;
                case(2):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=false;
                        soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        lifes-=1;
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=true;
                            mSoundPool2.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });break;
                case(3):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=false;
                        soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        lifes-=1;
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=true;
                            mSoundPool3.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });break;
                case(4):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=false;
                        soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        lifes-=1;
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=true;
                            mSoundPool4.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });break;
                case(5):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=false;
                        soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        lifes-=1;
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=true;
                            mSoundPool5.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });break;
                case(6):tile1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onButton=false;
                        soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        lifes-=1;
                    }
                });
                    tile2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=false;
                            soundPool.play(1,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                            lifes-=1;
                        }
                    });
                    tile6.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onButton=true;
                            mSoundPool6.play(2,leftVolume,rightVolume,priority,no_loop,normal_playback_rate);
                        }
                    });break;
            }

            if((counter==(leveldelays[counterdelays]/timerTime)) || onButton==true){
                switch (leveltiles[counterdelays+1]){
                    case(1):startbutton.setImageResource(R.drawable.guitar1);break;
                    case(2):startbutton.setImageResource(R.drawable.guitar2);break;
                    case(3):startbutton.setImageResource(R.drawable.guitar3);break;
                    case(4):startbutton.setImageResource(R.drawable.guitar4);break;
                    case(5):startbutton.setImageResource(R.drawable.baraban1);break;
                    case(6):startbutton.setImageResource(R.drawable.baraban2);break;
                }
                if (!onButton){
                    lifes-=1;
                }
                if(counterdelays+1<leveltiles.length-1){
                    counterdelays+=1;
                    counter=0;
                    onButton=false;
                }else{
                    onFinish();
                }
            }

        }

        @Override
        public void onFinish() {
            if(loseGame){
                startbutton.setImageResource(R.drawable.lose);
            }
            else{
                startbutton.setImageResource(R.drawable.win);
            }
            Intent intent=new Intent(LevelActivity.this,MainActivity.class);
            startActivity(intent);
        }
    }

}